export const requestComision = {
    "sessionId": "D3311638E721ED974DCE4745AA9CDF13",
    "token": "ENC(YwK5btVZI8msMfr0Z5zY48WKI9KGkAAjHrdVRcdflP7qciN0IWUn1zBTRfDkX4GZKpt0souEKEqFgvUnmlDVkwL68bX2GK0ysb+BlGmbV1tMTPbknoJXxw==)",
    "uriTech": "uriTech=OPERADOR_EMPRESA@143495;uriSFB=CEDULA_DE_IDENTIDAD#1303915696;userName=bmovil_150547;OWNER=true;",
    "identificacion": "1303915696"
}

export const autorizacionSubPantalla = {
    "r1RsPyActual": "testing",
    "r2ClientId": "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJzZXNzaW9uSWQiOiJEMzMxMTYzOEU3MjFFRDk3NERDRTQ3NDVBQTlDREYxMyIsInRva2VuIjoiRU5DKFl3SzVidFZaSThtc01mcjBaNXpZNDhXS0k5S0drQUFqSHJkVlJjZGZsUDdxY2lOMElXVW4xekJUUmZEa1g0R1pLcHQwc291RUtFcUZndlVubWxEVmt3TDY4YlgyR0sweXNiK0JsR21iVjF0TVRQYmtub0pYeHc9PSkiLCJ1cmlUZWNoIjoidXJpVGVjaD1PUEVSQURPUl9FTVBSRVNBQDE0MzQ5NTt1cmlTRkI9Q0VEVUxBX0RFX0lERU5USURBRCMxMzAzOTE1Njk2O3VzZXJOYW1lPWJtb3ZpbF8xNTA1NDc7T1dORVI9dHJ1ZTsiLCJpYXQiOjE3NDM1MzkwNjl9.uTZLlt5AabX-F532Zk6rsUH_VdAot3IecM4Xex7pQ-f1x9-r2Axt9aCYw9tUIiNX_Jf4EYmHwyIEQACFjYNM4A"
}

export const interceptorRequest = {
    "r2ClientId": "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJzZXNzaW9uSWQiOiJEMzMxMTYzOEU3MjFFRDk3NERDRTQ3NDVBQTlDREYxMyIsInRva2VuIjoiRU5DKFl3SzVidFZaSThtc01mcjBaNXpZNDhXS0k5S0drQUFqSHJkVlJjZGZsUDdxY2lOMElXVW4xekJUUmZEa1g0R1pLcHQwc291RUtFcUZndlVubWxEVmt3TDY4YlgyR0sweXNiK0JsR21iVjF0TVRQYmtub0pYeHc9PSkiLCJ1cmlUZWNoIjoidXJpVGVjaD1PUEVSQURPUl9FTVBSRVNBQDE0MzQ5NTt1cmlTRkI9Q0VEVUxBX0RFX0lERU5USURBRCMxMzAzOTE1Njk2O3VzZXJOYW1lPWJtb3ZpbF8xNTA1NDc7T1dORVI9dHJ1ZTsiLCJpYXQiOjE3NDM1MzkwNjl9.uTZLlt5AabX-F532Zk6rsUH_VdAot3IecM4Xex7pQ-f1x9-r2Axt9aCYw9tUIiNX_Jf4EYmHwyIEQACFjYNM4A",
    "r3HashAnterior": "zVHa/+eiA8ul/zZeXYvhirLss3WfWFR9mbqo0/MePLgHiHDddnBJ50VNC9ESjMWtFz+acuRlcOSI8c2RDqlNVA==",
    "r1RsPyAnterior": "testing"
}

export const requestGenerarOtp = {
    "cliente": {
      "codigoMis": "0",
      "tipoIdentificacion": "C",
      "identificacion": "1303915696"
    },
    "mediosEnvio": [
      {
        "tipo": "M",
        "valor": "ycisnerp@bolivariano.com"
      }
    ],
    "tipoServicio": "QOTPI"
  };
  
  export const headersGenerarOtp = {
    "clientId": "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJzZXNzaW9uSWQiOiI0NzMxMzE5QUEyRTA2NzU1OTAzRUQ2NzNERkM5QjlBRCIsInRva2VuIjoiRU5DKHY5WCswdUJQYzZrZ1FQWHdEMnZzR1loSGl6NDdYUFBxWm9uWGhSeU8zU3Z6WXFaRHl4UFc0eTVZV1Rha2QvQSs0S2JPcG9DdVV4UlpvMDNwVnRpTmtmckplNGNKYVRpeEJBYWE5M1ROek1Bb1RMN1FtWVFFeUE9PSkiLCJ1cmlUZWNoIjoidXJpVGVjaD1PUEVSQURPUl9FTVBSRVNBQDE0MzQ5NTt1cmlTRkI9Q0VEVUxBX0RFX0lERU5USURBRCMxMzAzOTE1Njk2O3VzZXJOYW1lPWJtb3ZpbF8xNTA1NDc7T1dORVI9dHJ1ZTsiLCJpYXQiOjE3NDQwNjE1ODR9.j5L5tGkz2K-EOsMx5e-JGoKYvhfi0Ygc28p6YVivaC17YKRSVo9S295v9kS53-SZ8iwRiHyoAuQZZ0vStJAHdw",
    "secuencial": "12345678",
    "codigoMIS": "143495",
    "pais": "EC",
    "tipoLogin": "USR",
    "nombreEquipo": "device123",
    "serial": "serial123",
    "numero": "0987654321",
    "imei": "123456789012345",
    "marca": "Samsung",
    "modelo": "Galaxy S21",
    "ip": "192.168.1.1",
    "usuario": "testuser",
    "identificacion": "0905945770"
  };

  export const requestObtenerCupoDiario = {
    "tipoPersona": "1"
  }
  
  export const headersObtenerCupoDiario = {
    "clientId": "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJzZXNzaW9uSWQiOiI0NzMxMzE5QUEyRTA2NzU1OTAzRUQ2NzNERkM5QjlBRCIsInRva2VuIjoiRU5DKHY5WCswdUJQYzZrZ1FQWHdEMnZzR1loSGl6NDdYUFBxWm9uWGhSeU8zU3Z6WXFaRHl4UFc0eTVZV1Rha2QvQSs0S2JPcG9DdVV4UlpvMDNwVnRpTmtmckplNGNKYVRpeEJBYWE5M1ROek1Bb1RMN1FtWVFFeUE9PSkiLCJ1cmlUZWNoIjoidXJpVGVjaD1PUEVSQURPUl9FTVBSRVNBQDE0MzQ5NTt1cmlTRkI9Q0VEVUxBX0RFX0lERU5USURBRCMxMzAzOTE1Njk2O3VzZXJOYW1lPWJtb3ZpbF8xNTA1NDc7T1dORVI9dHJ1ZTsiLCJpYXQiOjE3NDQwNjE1ODR9.j5L5tGkz2K-EOsMx5e-JGoKYvhfi0Ygc28p6YVivaC17YKRSVo9S295v9kS53-SZ8iwRiHyoAuQZZ0vStJAHdw",
    "secuencial": "12345678",
    "codigoMIS": "143495",
    "pais": "EC",
    "tipoLogin": "USR",
    "nombreEquipo": "device123",
    "serial": "serial123",
    "numero": "0987654321",
    "imei": "123456789012345",
    "marca": "Samsung",
    "modelo": "Galaxy S21",
    "ip": "192.168.1.1",
    "usuario": "testuser",
    "identificacion": "0905945770"
  };

  export const requestRegPagoEfectivoPropio = {
    "ordenante":{
        "cliente": {
            "tipoIdentificacion": "C",
            "identificacion": "0905945770",
            "nombre": "ENRIQUE RAMIREZ"
        },
        "cuenta": {
            "cuenta": "0021095501",
            "tipoCuenta": "AHO"
        }
    },
    "beneficiario":{
       "cliente":{
          "tipoIdentificacion":"C",
          "identificacion":"0915572739",
          "nombre":"Propio",
          "telefono":"0983848028"
       }
    },
    "monto":"0.02",
    "descripcion":"Prueba"
}

export const headersRegPagoEfectivoPropio = {
  "clientId": "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJzZXNzaW9uSWQiOiJGMUNFRUM2RTE3NTZFMUU5RUEzNTNCOTI5ODBBN0E0OCIsInRva2VuIjoiRU5DKFdBWmF4ZjRSOGV6T0FkWFBSQ2oyTlZGby9yYlZjSEg0ckljKzRYazZTK3YyYkJjL3pKUjREUXdzZjgxYlZQeld6dS9NNFUra1JpaVdnMUxtbHNJK3RuMHFyWVdZTXJKbVBuM3pZYTJvcjlPTVFVaW1KRmo0c2c9PSkiLCJ1cmlUZWNoIjoidXJpVGVjaD1PUEVSQURPUl9FTVBSRVNBQDE0MzQ5NTt1cmlTRkI9Q0VEVUxBX0RFX0lERU5USURBRCMxMzAzOTE1Njk2O3VzZXJOYW1lPWJtb3ZpbF8xNTA1NDc7T1dORVI9dHJ1ZTsiLCJpYXQiOjE3NDQyMjk0NTh9.KGtUbNsBby85NaXYcLdj4x-2hlXRQsGY1OXiAES8_1NuJNnyDGwdjoNmHuWVHNCgd43YwgGotlMnc8QW7UznSg",
  "referenciaRes": "7SfDqlRDh6PbupV0YAmjXwrw3SHwf1hFkFyCWrVewBdFOXy8b2u7XfsJGe1u8mK/Kkx316fu9wag0/x46mNJ6w==",
  "hash": "mGcUyEOlw/j8UyVbv2ZE61J773tavZzf2qDlBKWsuWPq/zYjWoVApA1mFHJWoopCJv3iQlxI0WIGFoIfG4mKJQ==",
  "secuencial": "12345678",
  "codigoMIS": "143495",
  "pais": "EC",
  "tipoLogin": "USR",
  "nombreEquipo": "device123",
  "serial": "serial123",
  "numero": "0987654321",
  "imei": "123456789012345",
  "marca": "Samsung",
  "modelo": "Galaxy S21",
  "ip": "192.168.1.1",
  "usuario": "testuser",
  "identificacion": "0905945770"
};
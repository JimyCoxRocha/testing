export const valorHashDynamo = {
    "Item": {
        "expires_date": {
            "S": "2080-04-01 16:05:00"
        },
        "fueusado": {
            "S": "NO_FUE_USADO"
        },
        "id": {
            "S": "mGcUyEOlw/j8UyVbv2ZE61J773tavZzf2qDlBKWsuWPq/zYjWoVApA1mFHJWoopCJv3iQlxI0WIGFoIfG4mKJQ=="
        },
        "expires_at": {
            "N": "1743541500"
        }
    }

}

export const valorTokenDynamo = {
    "$metadata": {
        "httpStatusCode": 200,
        "requestId": "MT2BIJL8G6ISNTAR4EP3PSTL9VVV4KQNSO5AEMVJF66Q9ASUAAJG",
        "attempts": 1,
        "totalRetryDelay": 0
    },
    "Item": {
        "expires_date": {
            "S": "2025-04-09 14:15:26"
        },
        "uriTech": {
            "S": "uriTech=OPERADOR_EMPRESA@143495;uriSFB=CEDULA_DE_IDENTIDAD#1303915696;userName=bmovil_150547;OWNER=true;"
        },
        "sessionId": {
            "S": "9047FAA01F30A43D844B5608B70726F9"
        },
        "token": {
            "S": "ENC(heaY6sjX+3pW8Gs2LrhR8iLumhCIUwCRv9lSNnm4lc8Wju82tsBS+Z6uq9K6KkDf9qxmnM8lhTy+h2QoeCdMR3nUP1HbpMmgpJ6O0Gi8n8ML5iXS56DC/w==)"
        },
        "id": {
            "S": "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJzZXNzaW9uSWQiOiI5MDQ3RkFBMDFGMzBBNDNEODQ0QjU2MDhCNzA3MjZGOSIsInRva2VuIjoiRU5DKGhlYVk2c2pYKzNwVzhHczJMcmhSOGlMdW1oQ0lVd0NSdjlsU05ubTRsYzhXanU4MnRzQlMrWjZ1cTlLNktrRGY5cXhtbk04bGhUeStoMlFvZUNkTVIzblVQMUhicE1tZ3BKNk8wR2k4bjhNTDVpWFM1NkRDL3c9PSkiLCJ1cmlUZWNoIjoidXJpVGVjaD1PUEVSQURPUl9FTVBSRVNBQDE0MzQ5NTt1cmlTRkI9Q0VEVUxBX0RFX0lERU5USURBRCMxMzAzOTE1Njk2O3VzZXJOYW1lPWJtb3ZpbF8xNTA1NDc7T1dORVI9dHJ1ZTsiLCJpYXQiOjE3NDQyMjU1MjZ9.ZRC8aiHzRLPhPsM8QG6PHOQG45-Q63newR0uaBCfN3zkc7VSss0UMEam7F5_da4Kd-dkbtuaQ30xfNyJAOR8jA"
        },
        "expires_at": {
            "N": "1744226126"
        }
    }
}

export const obtenerCupoDiarioResponse = {
    "codigoError": "0",
    "mensajeSistema": "TRANSACCION EXITOSA",
    "mensajeUsuario": "TRANSACCION EXITOSA",
    "valorCupo": 100
}

export const registrarPagoEfectivoTercero = {
    "codigoError": "0",
    "mensajeUsuario": "Transacción exitosa",
    "ordenBanco": 115020684,
    "ordenEmpresa": 93591060,
    "fechaVencimiento": "2025/07/08",
    "claveOrdenante": "7075",
    "claveBeneficiario": "1654"
}
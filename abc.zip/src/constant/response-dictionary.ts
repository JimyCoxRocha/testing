export const DiccionarioMensajes = {
  mensajeGenerico: "No hemos podido validar su información",
  mensajeGenericoFraude: "No hemos podido validar su información",
  mensajeErrorRegistroDispositivo: "El nombre del dispositivo es inválido",
  codigoError: 0,
  codigoErrorFraude: 403,
  codigoErrorRegistroDispositivo: 1101,
  msgExitosoUsuarioGeneral: "TRANSACCION EXITOSA",
  msgErrorUsuarioGeneral: "No pudimos procesar tu información, por favor inténtalo mas tarde",
  formatoFechaHora: "YYYY-MM-DD HH:mm:ss"
}; 